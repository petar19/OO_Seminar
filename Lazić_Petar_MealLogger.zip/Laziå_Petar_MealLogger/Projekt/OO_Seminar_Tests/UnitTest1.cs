using Microsoft.VisualStudio.TestTools.UnitTesting;
using OO_Seminar;
using OO_Seminar.DomainModel;
using OO_Seminar.DomainModel.Repositories;
using OO_Seminar.DomainModel.Exceptions;

using OO_Seminar.RepositoriesImpl;
using System.Collections.Generic;
using System;

namespace OO_Seminar_Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestInitialize]
        public void ReInitializeMealRepository()
        {
            System.Reflection.FieldInfo fi = typeof(MealRepository).GetField("_instance",
                                                                                System.Reflection.BindingFlags.Static |
                                                                                System.Reflection.BindingFlags.NonPublic);

            Assert.IsNotNull(fi);

            fi.SetValue(null, null);
        }


        [TestMethod]
        public void TestAddingMeal()
        {
            IMealRepository mealRepository = MealRepository.getInstance(false);

            Meal meal = new Meal
            {
                Name = "Pizza",
                Description = "Pizzzza!",
                Calories = 8,
                Rating = 9,
                Price = 8,
                MealType = "ru�ak",
                Location = "restoran",
                PreparationType = "pe�enje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "�unka", Importance = 6},
                        new MealIngredient { Ingredient = "sir", Importance = 9},
                        new MealIngredient { Ingredient = "tijesto", Importance = 10},
                        new MealIngredient { Ingredient = "raj�ica", Importance = 10}
                    },
            };

            mealRepository.AddMeal(meal);

            var allMeals = mealRepository.GetAllMeals();
            Assert.AreEqual(1, mealRepository.GetNumberOfMeals());

            CollectionAssert.Contains(allMeals, meal);
        }

        [TestMethod]
        public void TestDeletingMeal()
        {
            IMealRepository mealRepository = MealRepository.getInstance(false);
            Assert.AreEqual(0, mealRepository.GetNumberOfMeals());

            Meal meal = new Meal
            {
                Name = "Pizza",
                Description = "Pizzzza!",
                Calories = 8,
                Rating = 9,
                Price = 8,
                MealType = "ru�ak",
                Location = "restoran",
                PreparationType = "pe�enje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "�unka", Importance = 6},
                        new MealIngredient { Ingredient = "sir", Importance = 9},
                        new MealIngredient { Ingredient = "tijesto", Importance = 10},
                        new MealIngredient { Ingredient = "raj�ica", Importance = 10}
                    },
            };

            mealRepository.AddMeal(meal);

            Assert.AreEqual(1, mealRepository.GetNumberOfMeals());
            CollectionAssert.Contains(mealRepository.GetAllMeals(), meal);


            mealRepository.DeleteMeal(meal);

            Assert.AreEqual(0, mealRepository.GetNumberOfMeals());
            CollectionAssert.DoesNotContain(mealRepository.GetAllMeals(), meal);

        }

        [TestMethod]
        public void TestSearchFilter()
        {
            IMealRepository mealRepository = MealRepository.getInstance(false);

            Meal m1 = new Meal
            {
                Name = "jelo",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Ingredients = new List<MealIngredient>(),
                Timestamp = new DateTime(2021, 1, 26, 5, 5, 5)
            };

            Meal m2 = new Meal
            {
                Name = "hrana jelo",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Ingredients = new List<MealIngredient>(),
                Timestamp = new DateTime(2021, 1, 27, 5, 5, 5)
            };

            Meal m3 = new Meal
            {
                Name = "rucak",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Ingredients = new List<MealIngredient>(),
                Timestamp = new DateTime(2021, 1, 28, 5, 5, 5)
            };

            Meal m4 = new Meal
            {
                Name = "rucak jelo",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Ingredients = new List<MealIngredient>(),
                Timestamp = new DateTime(2021, 1, 29, 5, 5, 5)
            };

            Meal m5 = new Meal
            {
                Name = "oo",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Ingredients = new List<MealIngredient>(),
                Timestamp = new DateTime(2021, 1, 30, 5, 5, 5)
            };

            mealRepository.AddMeal(m1);
            mealRepository.AddMeal(m2);
            mealRepository.AddMeal(m3);
            mealRepository.AddMeal(m4);
            mealRepository.AddMeal(m5);

            var mealsBetween27and29 = mealRepository.GetMealsInTimePeriodAndWithKeywords(new DateTime(2021, 1, 27), new DateTime(2021, 1, 30), new List<string>());
            CollectionAssert.AreEqual(new List<Meal> { m2, m3, m4 }, mealsBetween27and29);

            var mealsContaining_jelo = mealRepository.GetMealsInTimePeriodAndWithKeywords(DateTime.MinValue, DateTime.MaxValue, new List<string> { "jelo" });
            CollectionAssert.AreEqual(new List<Meal> { m1, m2, m4 }, mealsContaining_jelo);

            var mealsAfter28Containing_ooOr_jel = mealRepository.GetMealsInTimePeriodAndWithKeywords(new DateTime(2021, 1, 28), DateTime.MaxValue, new List<string> { "oo", "jel" });
            CollectionAssert.AreEqual(new List<Meal> { m4, m5 }, mealsAfter28Containing_ooOr_jel);

        }

        [TestMethod]
        [ExpectedException(typeof(DuplicateIngredientsException))]
        public void TestDuplicateIngredients()
        {
            IMealRepository mealRepository = MealRepository.getInstance(false);

            Meal meal = new Meal
            {
                Name = "Pizza",
                Description = "Pizzzza!",
                Calories = 8,
                Rating = 9,
                Price = 8,
                MealType = "ru�ak",
                Location = "restoran",
                PreparationType = "pe�enje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "sir", Importance = 6},
                        new MealIngredient { Ingredient = "tijesto", Importance = 10},
                        new MealIngredient { Ingredient = "sir", Importance = 9},
                        new MealIngredient { Ingredient = "raj�ica", Importance = 10}
                    },
            };

            mealRepository.AddMeal(meal);
        }
        

        [TestMethod]
        public void TestStatisticsAvg()
        {
            Statistics stats = new Statistics();

            Assert.AreEqual(0, stats.NumMeals);

            Meal m1 = new Meal
            {
                Name = "Meal1",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Location = "ku�a",
                PreparationType = "kuhanje",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "sastojak1", Importance = 6},
                        new MealIngredient { Ingredient = "sastojak2", Importance = 9},
                        new MealIngredient { Ingredient = "sastojak3", Importance = 10},
                        new MealIngredient { Ingredient = "sastojak4", Importance = 10}
                    },
            };

            Meal m2 = new Meal
            {
                Name = "Meal2",
                Calories = 8,
                Rating = 9,
                Price = 8,
                MealType = "doru�ak",
                Location = "ku�a",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "sastojak2", Importance = 5},
                        new MealIngredient { Ingredient = "sastojak3", Importance = 7},
                        new MealIngredient { Ingredient = "sastojak5", Importance = 6}
                    },
            };

            Meal m3 = new Meal
            {
                Name = "Meal3",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Location = "ku�a",
                PreparationType = "kuhanje",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "sastojak4", Importance = 6},
                        new MealIngredient { Ingredient = "sastojak3", Importance = 9},
                        new MealIngredient { Ingredient = "sastojak1", Importance = 10},
                    },
            };

            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m2);
            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m3);
            stats.AddStatsForMeal(m3);
            stats.AddStatsForMeal(m2);
            stats.AddStatsForMeal(m2);
            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m2);


            Assert.AreEqual(11, stats.NumMeals);

            Assert.AreEqual((5 * m1.Rating + 4 * m2.Rating + 2 * m3.Rating) / 11.0, stats.AvgRating);
            Assert.AreEqual((5 * m1.Price + 4 * m2.Price + 2 * m3.Price) / 11.0, stats.AvgPrice);
            Assert.AreEqual((5 * m1.Calories + 4 * m2.Calories + 2 * m3.Calories) / 11.0, stats.AvgCalories);
        }

        [TestMethod]
        public void TestStatisticsCounts()
        {
            Statistics stats = new Statistics();

            Assert.AreEqual(0, stats.NumMeals);

            Meal m1 = new Meal
            {
                Name = "Meal1",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Location = "restoran",
                PreparationType = "kuhanje",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "sastojak1", Importance = 6},
                        new MealIngredient { Ingredient = "sastojak2", Importance = 9},
                        new MealIngredient { Ingredient = "sastojak3", Importance = 10},
                        new MealIngredient { Ingredient = "sastojak4", Importance = 10}
                    },
            };

            Meal m2 = new Meal
            {
                Name = "Meal2",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Location = "ku�a",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "sastojak2", Importance = 5},
                        new MealIngredient { Ingredient = "sastojak3", Importance = 7},
                        new MealIngredient { Ingredient = "sastojak5", Importance = 6}
                    },
            };

            Meal m3 = new Meal
            {
                Name = "Meal3",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Location = "ku�a",
                PreparationType = "kuhanje",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "sastojak4", Importance = 6},
                        new MealIngredient { Ingredient = "sastojak3", Importance = 9},
                        new MealIngredient { Ingredient = "sastojak1", Importance = 10},
                    },
            };

            stats.AddStatsForMeal(m2);
            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m3);
            stats.AddStatsForMeal(m3);
            stats.AddStatsForMeal(m3);
            stats.AddStatsForMeal(m2);
            stats.AddStatsForMeal(m2);
            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m1);
            stats.AddStatsForMeal(m2);


            Assert.AreEqual(10, stats.NumMeals);

            Assert.AreEqual(3, stats.MealNames["Meal1"]);
            Assert.AreEqual(4, stats.MealNames["Meal2"]);
            Assert.AreEqual(3, stats.MealNames["Meal3"]);

            Assert.AreEqual(4, stats.PreparationTypes["Nepoznato"]);

            Assert.AreEqual(3, stats.Locations["restoran"]);
            Assert.AreEqual(7, stats.Locations["ku�a"]);

            Assert.AreEqual(7, stats.Locations["ku�a"]);

            Assert.AreEqual(7, stats.Ingredients["sastojak2"]);
            Assert.AreEqual(4, stats.Ingredients["sastojak5"]);

        }


        [TestMethod]
        public void TestSuggestionSimple()
        {
            Suggestions suggestions = new Suggestions();

            Meal m1 = new Meal
            {
                Name = "jelo koje nisam dugo jeo",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Ingredients = new List<MealIngredient>(),
            };

            Meal m2 = new Meal
            {
                Name = "jelo",
                Calories = 8,
                Rating = 9,
                Price = 8,
                Ingredients = new List<MealIngredient>(),
            };

          

            var meals = new List<Meal> { m2, m2, m2, m1 };

            var suggestedMeal = suggestions.GetSuggestedMeals(meals, meals, 1)[0];

            Assert.AreEqual(m1, suggestedMeal);
        }


        [TestMethod]
        public void TestSuggestionsComplex()
        {
            Suggestions suggestions = new Suggestions();

            Meal pizza = new Meal
            {
                Name = "Pizza",
                Calories = 8,
                Rating = 9,
                Price = 8,
                MealType = "ru�ak",
                Location = "restoran",
                PreparationType = "pe�enje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "�unka", Importance = 6},
                        new MealIngredient { Ingredient = "sir", Importance = 9},
                        new MealIngredient { Ingredient = "tijesto", Importance = 10},
                        new MealIngredient { Ingredient = "raj�ica", Importance = 10}
                    },
            };

            Meal sarma = new Meal
            {
                Name = "Sarma",
                Calories = 8,
                Rating = 10,
                Price = 6,
                MealType = "ru�ak",
                Location = "ku�a",
                PreparationType = "kuhanje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "mljeveno meso", Importance = 10},
                        new MealIngredient { Ingredient = "kupus", Importance = 10},
                        new MealIngredient { Ingredient = "krumpir", Importance = 8},
                    },
            };

            Meal kupusBuncek = new Meal
            {
                Name = "Kupus i buncek",
                Calories = 7,
                Rating = 8,
                Price = 6,
                MealType = "ru�ak",
                Location = "ku�a",
                PreparationType = "kuhanje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "buncek", Importance = 10},
                        new MealIngredient { Ingredient = "kupus", Importance = 10},
                    },
            };

            Meal sendvic = new Meal
            {
                Name = "sendvi�",
                Calories = 8,
                Rating = 8,
                Price = 7,
                MealType = "doru�ak",
                Location = "ku�a",
                PreparationType = "slaganje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "�unka", Importance = 8},
                        new MealIngredient { Ingredient = "pecivo", Importance = 10},
                        new MealIngredient { Ingredient = "sir", Importance = 8},
                        new MealIngredient { Ingredient = "salata", Importance = 7},
                    },
            };

            Meal burger = new Meal
            {
                Name = "burger",
                Calories = 10,
                Rating = 9,
                Price = 9,
                MealType = "doru�ak",
                Location = "restoran",
                PreparationType = "slaganje",
                DishType = "glavno jelo",
                Ingredients = new List<MealIngredient>
                    {
                        new MealIngredient { Ingredient = "meso", Importance = 10},
                        new MealIngredient { Ingredient = "pecivo", Importance = 10},
                        new MealIngredient { Ingredient = "sir", Importance = 9},
                        new MealIngredient { Ingredient = "salata", Importance = 7},
                        new MealIngredient { Ingredient = "umak", Importance = 8},
                    },
            };


            var allMeals = new List<Meal> { pizza, sarma, kupusBuncek, sendvic, burger };

            var suggestedMeals = suggestions.GetSuggestedMeals(new List<Meal> { sarma, sendvic, sarma, sarma, sendvic, sarma, sarma }, allMeals, 4);

            // ako se sarma pojavljuje cesto u zadnjih nekoliko jela koja smo jeli, preporuka ne bi trebala sadrzavati jelo "Kupus i buncek" koje je slicno sarmi jer je tako�er kuhano i glavni sastojak je kupus
            CollectionAssert.DoesNotContain(suggestedMeals, kupusBuncek);

            // slicno kao prije, zadnja jela koja smo jeli su uglavnom "fast food" pa preporuke za sljedecih par jela ne sadrze ta jela
            var suggestedMeals2 = suggestions.GetSuggestedMeals(new List<Meal> { pizza, burger, pizza, pizza, burger}, allMeals, 4);
            CollectionAssert.IsNotSubsetOf(new List<Meal> { pizza, burger, sendvic}, suggestedMeals2);

        }
    }
}
